<?php
// index.php - Modern Dashboard
require_once 'config/database.php';
require_once 'includes/functions.php';

$pageTitle = 'Dashboard';

$db = new Database();
$conn = $db->connect();

// Get statistics
$stmt = $conn->query("SELECT SUM(jumlah_total) as total FROM infocus");
$totalInfocus = $stmt->fetch()['total'] ?: 0;

$stmt = $conn->query("SELECT SUM(jumlah_tersedia) as total FROM infocus");
$infocusTersedia = $stmt->fetch()['total'] ?: 0;

$infocusDipinjam = $totalInfocus - $infocusTersedia;

$stmt = $conn->query("SELECT COUNT(*) as total FROM peminjam");
$totalPeminjam = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM peminjaman WHERE status = 'Dipinjam'");
$peminjamanAktif = $stmt->fetch()['total'];

// Get recent peminjaman
$stmt = $conn->query("
    SELECT p.*, pm.nama as nama_peminjam, a.nama_lengkap as nama_admin
    FROM peminjaman p
    JOIN peminjam pm ON p.id_peminjam = pm.id_peminjam
    JOIN admin a ON p.id_admin = a.id_admin
    ORDER BY p.created_at DESC
    LIMIT 5
");
$recentPeminjaman = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="row mb-4">
    <div class="col-12">
        <h2 class="mb-1">
            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
        </h2>
        <p class="text-muted">Selamat datang, <strong><?= $_SESSION['admin_name'] ?></strong>!</p>
    </div>
</div>

<?php showAlert(); ?>

<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="dashboard-card card-blue">
            <h3><?= $totalInfocus ?></h3>
            <p>Total Unit Infocus</p>
            <i class="fas fa-video"></i>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="dashboard-card card-green">
            <h3><?= $infocusTersedia ?></h3>
            <p>Unit Tersedia</p>
            <i class="fas fa-check-circle"></i>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="dashboard-card card-orange">
            <h3><?= $infocusDipinjam ?></h3>
            <p>Sedang Dipinjam</p>
            <i class="fas fa-exchange-alt"></i>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="dashboard-card card-red">
            <h3><?= $totalPeminjam ?></h3>
            <p>Total Peminjam</p>
            <i class="fas fa-users"></i>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-history me-2"></i>Peminjaman Terbaru
            </div>
            <div class="card-body">
                <?php if (count($recentPeminjaman) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-custom table-hover mb-0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>ID</th>
                                <th>Tanggal Pinjam</th>
                                <th>Peminjam</th>
                                <th>Tanggal Kembali</th>
                                <th>Keperluan</th>
                                <th>Status</th>
                                <th>Admin</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentPeminjaman as $index => $row): ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td><strong>#<?= str_pad($row['id_peminjaman'], 4, '0', STR_PAD_LEFT) ?></strong></td>
                                <td><?= formatTanggal($row['tanggal_pinjam']) ?></td>
                                <td><strong><?= $row['nama_peminjam'] ?></strong></td>
                                <td><?= formatTanggal($row['tanggal_kembali_rencana']) ?></td>
                                <td><?= substr($row['keperluan'], 0, 40) ?>...</td>
                                <td>
                                    <?php 
                                    $statusClass = 'status-' . strtolower($row['status']);
                                    ?>
                                    <span class="badge <?= $statusClass ?>">
                                        <?= $row['status'] ?>
                                    </span>
                                </td>
                                <td><?= $row['nama_admin'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="text-end mt-3">
                    <a href="riwayat.php" class="btn btn-sm btn-primary">
                        Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
                <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                    <p class="text-muted">Belum ada data peminjaman</p>
                    <a href="peminjaman.php" class="btn btn-primary mt-2">
                        <i class="fas fa-plus me-2"></i>Buat Peminjaman Baru
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
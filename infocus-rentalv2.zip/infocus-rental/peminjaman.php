<?php
// peminjaman.php - Modern Version with Unit System
require_once 'config/database.php';
require_once 'includes/functions.php';

$pageTitle = 'Peminjaman';

$db = new Database();
$conn = $db->connect();

// Handle Add Peminjaman
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $id_peminjam = $_POST['id_peminjam'];
    $tanggal_pinjam = $_POST['tanggal_pinjam'];
    $tanggal_kembali_rencana = $_POST['tanggal_kembali_rencana'];
    $keperluan = clean($_POST['keperluan']);
    $id_admin = $_SESSION['admin_id'];
    $unit_items = isset($_POST['units']) ? $_POST['units'] : [];
    
    if (count($unit_items) == 0) {
        setAlert('error', 'Pilih minimal 1 unit infocus!');
        header('Location: peminjaman.php');
        exit();
    }
    
    try {
        $conn->beginTransaction();
        
        // Insert peminjaman
        $stmt = $conn->prepare("INSERT INTO peminjaman (id_peminjam, id_admin, tanggal_pinjam, tanggal_kembali_rencana, keperluan, status) VALUES (?, ?, ?, ?, ?, 'Dipinjam')");
        $stmt->execute([$id_peminjam, $id_admin, $tanggal_pinjam, $tanggal_kembali_rencana, $keperluan]);
        
        $id_peminjaman = $conn->lastInsertId();
        
        // Insert detail peminjaman dan update status unit
        foreach ($unit_items as $id_unit) {
            // Get kondisi unit
            $stmt = $conn->prepare("SELECT kondisi FROM unit_infocus WHERE id_unit = ?");
            $stmt->execute([$id_unit]);
            $kondisi = $stmt->fetch()['kondisi'];
            
            // Insert detail
            $stmt = $conn->prepare("INSERT INTO detail_peminjaman (id_peminjaman, id_unit, kondisi_pinjam) VALUES (?, ?, ?)");
            $stmt->execute([$id_peminjaman, $id_unit, $kondisi]);
            
            // Update status unit
            $stmt = $conn->prepare("UPDATE unit_infocus SET status = 'Dipinjam' WHERE id_unit = ?");
            $stmt->execute([$id_unit]);
            
            // Update jumlah tersedia di master infocus
            $stmt = $conn->prepare("
                UPDATE infocus i
                JOIN unit_infocus u ON i.id_infocus = u.id_infocus
                SET i.jumlah_tersedia = i.jumlah_tersedia - 1
                WHERE u.id_unit = ?
            ");
            $stmt->execute([$id_unit]);
        }
        
        $conn->commit();
        setAlert('success', 'Peminjaman berhasil ditambahkan dengan ' . count($unit_items) . ' unit!');
    } catch (Exception $e) {
        $conn->rollBack();
        setAlert('error', 'Gagal menambahkan peminjaman: ' . $e->getMessage());
    }
    
    header('Location: peminjaman.php');
    exit();
}

// Handle Return
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'return') {
    $id_peminjaman = $_POST['id_peminjaman'];
    $tanggal_kembali = date('Y-m-d');
    
    try {
        $conn->beginTransaction();
        
        // Get detail peminjaman
        $stmt = $conn->prepare("SELECT id_unit FROM detail_peminjaman WHERE id_peminjaman = ?");
        $stmt->execute([$id_peminjaman]);
        $details = $stmt->fetchAll();
        
        // Update status unit ke tersedia
        foreach ($details as $detail) {
            $stmt = $conn->prepare("UPDATE unit_infocus SET status = 'Tersedia' WHERE id_unit = ?");
            $stmt->execute([$detail['id_unit']]);
            
            // Update jumlah tersedia di master infocus
            $stmt = $conn->prepare("
                UPDATE infocus i
                JOIN unit_infocus u ON i.id_infocus = u.id_infocus
                SET i.jumlah_tersedia = i.jumlah_tersedia + 1
                WHERE u.id_unit = ?
            ");
            $stmt->execute([$detail['id_unit']]);
        }
        
        // Update peminjaman
        $stmt = $conn->prepare("UPDATE peminjaman SET tanggal_kembali_aktual = ?, status = 'Dikembalikan' WHERE id_peminjaman = ?");
        $stmt->execute([$tanggal_kembali, $id_peminjaman]);
        
        $conn->commit();
        setAlert('success', 'Pengembalian berhasil!');
    } catch (Exception $e) {
        $conn->rollBack();
        setAlert('error', 'Gagal memproses pengembalian: ' . $e->getMessage());
    }
    
    header('Location: peminjaman.php');
    exit();
}

// Get active peminjaman
$stmt = $conn->query("
    SELECT p.*, pm.nama as nama_peminjam, pm.nip, a.nama_lengkap as nama_admin
    FROM peminjaman p
    JOIN peminjam pm ON p.id_peminjam = pm.id_peminjam
    JOIN admin a ON p.id_admin = a.id_admin
    WHERE p.status = 'Dipinjam'
    ORDER BY p.tanggal_pinjam DESC
");
$dataPeminjaman = $stmt->fetchAll();

// Get peminjam
$stmt = $conn->query("SELECT * FROM peminjam ORDER BY nama");
$dataPeminjam = $stmt->fetchAll();

// Get available infocus grouped by model
$stmt = $conn->query("
    SELECT i.*, 
           (SELECT COUNT(*) FROM unit_infocus u WHERE u.id_infocus = i.id_infocus AND u.status = 'Tersedia') as unit_tersedia
    FROM infocus i
    WHERE i.jumlah_tersedia > 0
    ORDER BY i.merk, i.model
");
$dataInfocus = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="mb-0">
            <i class="fas fa-exchange-alt me-2"></i>Data Peminjaman Aktif
        </h2>
        <p class="text-muted mt-2">Kelola peminjaman yang sedang berlangsung</p>
    </div>
    <div class="col-md-6 text-end">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalPeminjaman">
            <i class="fas fa-plus me-2"></i>Tambah Peminjaman
        </button>
    </div>
</div>

<?php showAlert(); ?>

<div class="card">
    <div class="card-body">
        <?php if (count($dataPeminjaman) > 0): ?>
        <div class="table-responsive">
            <table class="table table-custom table-hover mb-0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID</th>
                        <th>Tanggal Pinjam</th>
                        <th>Peminjam</th>
                        <th>NIP</th>
                        <th>Jumlah Unit</th>
                        <th>Tanggal Kembali</th>
                        <th>Keperluan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($dataPeminjaman as $index => $row): ?>
                    <?php
                    // Get detail infocus
                    $stmt = $conn->prepare("
                        SELECT i.merk, i.model, u.nomor_seri
                        FROM detail_peminjaman dp
                        JOIN unit_infocus u ON dp.id_unit = u.id_unit
                        JOIN infocus i ON u.id_infocus = i.id_infocus
                        WHERE dp.id_peminjaman = ?
                    ");
                    $stmt->execute([$row['id_peminjaman']]);
                    $infocusDetail = $stmt->fetchAll();
                    
                    // Check if late
                    $today = new DateTime();
                    $kembali = new DateTime($row['tanggal_kembali_rencana']);
                    $isLate = $today > $kembali;
                    ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><strong>#<?= str_pad($row['id_peminjaman'], 4, '0', STR_PAD_LEFT) ?></strong></td>
                        <td><?= formatTanggal($row['tanggal_pinjam']) ?></td>
                        <td><strong><?= $row['nama_peminjam'] ?></strong></td>
                        <td><?= $row['nip'] ?></td>
                        <td>
                            <span class="badge bg-info"><?= count($infocusDetail) ?> Unit</span>
                        </td>
                        <td>
                            <?= formatTanggal($row['tanggal_kembali_rencana']) ?>
                            <?php if ($isLate): ?>
                                <br><span class="badge bg-danger">Terlambat</span>
                            <?php endif; ?>
                        </td>
                        <td><?= substr($row['keperluan'], 0, 30) ?>...</td>
                        <td>
                            <span class="badge status-dipinjam">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-info" onclick="viewDetail(<?= htmlspecialchars(json_encode($infocusDetail)) ?>, '<?= $row['nama_peminjam'] ?>')">
                                <i class="fas fa-eye"></i>
                            </button>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="return">
                                <input type="hidden" name="id_peminjaman" value="<?= $row['id_peminjaman'] ?>">
                                <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Konfirmasi pengembalian?')">
                                    <i class="fas fa-check"></i> Kembalikan
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
            <p class="text-muted mb-3">Belum ada peminjaman aktif</p>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalPeminjaman">
                <i class="fas fa-plus me-2"></i>Buat Peminjaman Baru
            </button>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Add Peminjaman -->
<div class="modal fade" id="modalPeminjaman" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Peminjaman</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Peminjam</label>
                            <select class="form-select" name="id_peminjam" required>
                                <option value="">Pilih Peminjam</option>
                                <?php foreach ($dataPeminjam as $p): ?>
                                <option value="<?= $p['id_peminjam'] ?>"><?= $p['nama'] ?> (<?= $p['nip'] ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Keperluan</label>
                            <input type="text" class="form-control" name="keperluan" placeholder="Presentasi, Rapat, dll" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Pinjam</label>
                            <input type="date" class="form-control" name="tanggal_pinjam" id="tanggal_pinjam" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Kembali (Rencana)</label>
                            <input type="date" class="form-control" name="tanggal_kembali_rencana" id="tanggal_kembali_rencana" onchange="validateDate()" required>
                        </div>
                    </div>
                    
                    <hr>
                    <h6 class="mb-3"><i class="fas fa-video me-2"></i>Pilih Unit Infocus</h6>
                    
                    <div class="row">
                        <?php foreach ($dataInfocus as $inf): ?>
                            <?php
                            // Get available units for this model
                            $stmt = $conn->prepare("SELECT * FROM unit_infocus WHERE id_infocus = ? AND status = 'Tersedia' ORDER BY nomor_seri");
                            $stmt->execute([$inf['id_infocus']]);
                            $availableUnits = $stmt->fetchAll();
                            ?>
                            
                            <?php if (count($availableUnits) > 0): ?>
                            <div class="col-md-6 mb-3">
                                <div class="card infocus-card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <div>
                                                <h6 class="mb-0"><strong><?= $inf['merk'] ?> <?= $inf['model'] ?></strong></h6>
                                                <small class="text-muted"><?= count($availableUnits) ?> unit tersedia</small>
                                            </div>
                                            <?php if ($inf['foto']): ?>
                                                <img src="uploads/infocus/<?= $inf['foto'] ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 8px;">
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="mt-2">
                                            <?php foreach ($availableUnits as $unit): ?>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input" type="checkbox" name="units[]" value="<?= $unit['id_unit'] ?>" id="unit<?= $unit['id_unit'] ?>">
                                                <label class="form-check-label" for="unit<?= $unit['id_unit'] ?>">
                                                    <small><strong><?= $unit['nomor_seri'] ?></strong></small>
                                                    <small class="text-muted"> - <?= $unit['kondisi'] ?></small>
                                                </label>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Simpan Peminjaman
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Detail -->
<div class="modal fade" id="modalDetail" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalDetailTitle">Detail Unit</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="detailContent">
            </div>
        </div>
    </div>
</div>

<script>
function viewDetail(units, peminjam) {
    document.getElementById('modalDetailTitle').innerText = 'Detail Unit - ' + peminjam;
    
    let html = '<div class="table-responsive"><table class="table table-sm">';
    html += '<thead><tr><th>No</th><th>Merk/Model</th><th>Nomor Seri</th></tr></thead><tbody>';
    
    units.forEach((unit, index) => {
        html += '<tr>';
        html += '<td>' + (index + 1) + '</td>';
        html += '<td><strong>' + unit.merk + ' ' + unit.model + '</strong></td>';
        html += '<td>' + unit.nomor_seri + '</td>';
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    
    document.getElementById('detailContent').innerHTML = html;
    
    var modal = new bootstrap.Modal(document.getElementById('modalDetail'));
    modal.show();
}
</script>

<?php include 'includes/footer.php'; ?>
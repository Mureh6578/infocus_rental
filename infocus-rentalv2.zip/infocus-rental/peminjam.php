<?php
// peminjam.php
require_once 'config/database.php';
require_once 'includes/functions.php';

$pageTitle = 'Data Peminjam';

$db = new Database();
$conn = $db->connect();

// Handle Add/Edit/Delete
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add' || $action == 'edit') {
            $nama = clean($_POST['nama']);
            $nip = clean($_POST['nip']);
            $jabatan = clean($_POST['jabatan']);
            $no_telepon = clean($_POST['no_telepon']);
            
            if ($action == 'add') {
                $stmt = $conn->prepare("INSERT INTO peminjam (nama, nip, jabatan, no_telepon) VALUES (?, ?, ?, ?)");
                $stmt->execute([$nama, $nip, $jabatan, $no_telepon]);
                setAlert('success', 'Data peminjam berhasil ditambahkan!');
            } else {
                $id = $_POST['id_peminjam'];
                $stmt = $conn->prepare("UPDATE peminjam SET nama=?, nip=?, jabatan=?, no_telepon=? WHERE id_peminjam=?");
                $stmt->execute([$nama, $nip, $jabatan, $no_telepon, $id]);
                setAlert('success', 'Data peminjam berhasil diperbarui!');
            }
        } elseif ($action == 'delete') {
            $id = $_POST['id_peminjam'];
            $stmt = $conn->prepare("DELETE FROM peminjam WHERE id_peminjam = ?");
            $stmt->execute([$id]);
            setAlert('success', 'Data peminjam berhasil dihapus!');
        }
        
        header('Location: peminjam.php');
        exit();
    }
}

// Get all peminjam
$stmt = $conn->query("SELECT * FROM peminjam ORDER BY nama");
$dataPeminjam = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="mb-0">
            <i class="fas fa-users me-2"></i>Data Peminjam
        </h2>
    </div>
    <div class="col-md-6 text-end">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalPeminjam" onclick="resetForm()">
            <i class="fas fa-plus me-2"></i>Tambah Peminjam
        </button>
    </div>
</div>

<?php showAlert(); ?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>NIP</th>
                        <th>Jabatan</th>
                        <th>No. Telepon</th>
                        <th>Terdaftar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($dataPeminjam as $index => $row): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><strong><?= $row['nama'] ?></strong></td>
                        <td><?= $row['nip'] ?></td>
                        <td><?= $row['jabatan'] ?></td>
                        <td><?= $row['no_telepon'] ?></td>
                        <td><?= formatTanggal(date('Y-m-d', strtotime($row['created_at']))) ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick="editPeminjam(<?= htmlspecialchars(json_encode($row)) ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id_peminjam" value="<?= $row['id_peminjam'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger btn-delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Add/Edit Peminjam -->
<div class="modal fade" id="modalPeminjam" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Tambah Peminjam</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" id="formPeminjam">
                <div class="modal-body">
                    <input type="hidden" name="action" id="action" value="add">
                    <input type="hidden" name="id_peminjam" id="id_peminjam">
                    
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" name="nama" id="nama" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">NIP</label>
                        <input type="text" class="form-control number-only" name="nip" id="nip" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Jabatan</label>
                        <input type="text" class="form-control" name="jabatan" id="jabatan">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">No. Telepon</label>
                        <input type="text" class="form-control number-only" name="no_telepon" id="no_telepon">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('formPeminjam').reset();
    document.getElementById('action').value = 'add';
    document.getElementById('modalTitle').innerText = 'Tambah Peminjam';
}

function editPeminjam(data) {
    document.getElementById('action').value = 'edit';
    document.getElementById('id_peminjam').value = data.id_peminjam;
    document.getElementById('nama').value = data.nama;
    document.getElementById('nip').value = data.nip;
    document.getElementById('jabatan').value = data.jabatan;
    document.getElementById('no_telepon').value = data.no_telepon;
    document.getElementById('modalTitle').innerText = 'Edit Peminjam';
    
    var modal = new bootstrap.Modal(document.getElementById('modalPeminjam'));
    modal.show();
}
</script>

<?php include 'includes/footer.php'; ?>
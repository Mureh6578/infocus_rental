<?php
// includes/functions.php

session_start();

// Cek apakah user sudah login
function isLoggedIn() {
    return isset($_SESSION['admin_id']);
}

// Redirect jika belum login
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

// Format tanggal Indonesia
function formatTanggal($tanggal) {
    if (!$tanggal) return '-';
    $bulan = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    $split = explode('-', $tanggal);
    return $split[2] . ' ' . $bulan[(int)$split[1]] . ' ' . $split[0];
}

// Upload foto
function uploadFoto($file, $folder = 'uploads/infocus/') {
    $target_dir = $folder;
    
    // Buat folder jika belum ada
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $imageFileType = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
    $newFileName = uniqid() . '_' . time() . '.' . $imageFileType;
    $target_file = $target_dir . $newFileName;
    
    // Cek apakah file adalah gambar
    $check = getimagesize($file["tmp_name"]);
    if($check === false) {
        return ['success' => false, 'message' => 'File bukan gambar'];
    }
    
    // Cek ukuran file (max 5MB)
    if ($file["size"] > 5000000) {
        return ['success' => false, 'message' => 'Ukuran file terlalu besar (max 5MB)'];
    }
    
    // Hanya izinkan format tertentu
    if(!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
        return ['success' => false, 'message' => 'Hanya file JPG, JPEG, PNG & GIF yang diizinkan'];
    }
    
    // Upload file
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        return ['success' => true, 'filename' => $newFileName];
    } else {
        return ['success' => false, 'message' => 'Gagal mengupload file'];
    }
}

// Hapus foto
function deleteFoto($filename, $folder = 'uploads/infocus/') {
    $file_path = $folder . $filename;
    if (file_exists($file_path)) {
        unlink($file_path);
    }
}

// Sanitize input
function clean($string) {
    return htmlspecialchars(strip_tags(trim($string)));
}

// Alert helper
function setAlert($type, $message) {
    $_SESSION['alert'] = [
        'type' => $type,
        'message' => $message
    ];
}

function showAlert() {
    if (isset($_SESSION['alert'])) {
        $alert = $_SESSION['alert'];
        $icon = $alert['type'] == 'success' ? 'check-circle' : 'exclamation-triangle';
        $color = $alert['type'] == 'success' ? 'success' : ($alert['type'] == 'error' ? 'danger' : 'warning');
        
        echo '<div class="alert alert-' . $color . ' alert-dismissible fade show" role="alert">
                <i class="fas fa-' . $icon . ' me-2"></i>' . $alert['message'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        
        unset($_SESSION['alert']);
    }
}
?>
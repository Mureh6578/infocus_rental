-- Database: infocus_rental

CREATE DATABASE IF NOT EXISTS infocus_rental;
USE infocus_rental;

-- Tabel Admin (Master)
CREATE TABLE admin (
    id_admin INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Peminjam (Master)
CREATE TABLE peminjam (
    id_peminjam INT PRIMARY KEY AUTO_INCREMENT,
    nama VARCHAR(100) NOT NULL,
    nip VARCHAR(50) UNIQUE NOT NULL,
    jabatan VARCHAR(100),
    no_telepon VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Infocus (Master) - Grouped by Model
CREATE TABLE infocus (
    id_infocus INT PRIMARY KEY AUTO_INCREMENT,
    model VARCHAR(100) NOT NULL,
    merk VARCHAR(50) NOT NULL,
    jumlah_total INT NOT NULL DEFAULT 1,
    jumlah_tersedia INT NOT NULL DEFAULT 1,
    foto VARCHAR(255),
    keterangan TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_model (merk, model)
);

-- Tabel Unit Infocus (Detail per unit)
CREATE TABLE unit_infocus (
    id_unit INT PRIMARY KEY AUTO_INCREMENT,
    id_infocus INT NOT NULL,
    nomor_seri VARCHAR(100) UNIQUE NOT NULL,
    kondisi ENUM('Baik', 'Rusak Ringan', 'Rusak Berat') DEFAULT 'Baik',
    status ENUM('Tersedia', 'Dipinjam', 'Maintenance') DEFAULT 'Tersedia',
    keterangan_unit TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_infocus) REFERENCES infocus(id_infocus) ON DELETE CASCADE
);

-- Tabel Peminjaman (Master Detail - Header)
CREATE TABLE peminjaman (
    id_peminjaman INT PRIMARY KEY AUTO_INCREMENT,
    id_peminjam INT NOT NULL,
    id_admin INT NOT NULL,
    tanggal_pinjam DATE NOT NULL,
    tanggal_kembali_rencana DATE NOT NULL,
    tanggal_kembali_aktual DATE NULL,
    keperluan TEXT,
    status ENUM('Dipinjam', 'Dikembalikan', 'Terlambat') DEFAULT 'Dipinjam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_peminjam) REFERENCES peminjam(id_peminjam),
    FOREIGN KEY (id_admin) REFERENCES admin(id_admin)
);

-- Tabel Detail Peminjaman (Master Detail - Detail)
CREATE TABLE detail_peminjaman (
    id_detail INT PRIMARY KEY AUTO_INCREMENT,
    id_peminjaman INT NOT NULL,
    id_unit INT NOT NULL,
    kondisi_pinjam ENUM('Baik', 'Rusak Ringan', 'Rusak Berat') DEFAULT 'Baik',
    kondisi_kembali ENUM('Baik', 'Rusak Ringan', 'Rusak Berat') NULL,
    keterangan TEXT,
    FOREIGN KEY (id_peminjaman) REFERENCES peminjaman(id_peminjaman) ON DELETE CASCADE,
    FOREIGN KEY (id_unit) REFERENCES unit_infocus(id_unit)
);

-- Insert admin default (password: admin123)
INSERT INTO admin (username, password, nama_lengkap) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator');

-- Insert data contoh peminjam
INSERT INTO peminjam (nama, nip, jabatan, no_telepon) VALUES
('Budi Santoso', '198501012010011001', 'Guru Matematika', '081234567890'),
('Siti Aminah', '198702152011012002', 'Guru Bahasa Indonesia', '082345678901'),
('Ahmad Rizki', '199003202015011003', 'Guru IPA', '083456789012');

-- Insert data contoh infocus (grouped by model)
INSERT INTO infocus (model, merk, jumlah_total, jumlah_tersedia, keterangan) VALUES
('EB-X05', 'Epson', 5, 5, 'Proyektor standar untuk kelas - Resolusi XGA'),
('VPL-EX455', 'Sony', 3, 3, 'Proyektor HD untuk aula - 3600 lumens'),
('PT-LB423', 'Panasonic', 4, 3, 'Proyektor portable - Lightweight'),
('EB-2250U', 'Epson', 2, 2, 'Proyektor WUXGA - Full HD'),
('VPL-FHZ75', 'Sony', 1, 1, 'Proyektor Laser - 4K ready');

-- Insert unit infocus
INSERT INTO unit_infocus (id_infocus, nomor_seri, kondisi, status, keterangan_unit) VALUES
-- Epson EB-X05 (5 units)
(1, 'EPSON-001', 'Baik', 'Tersedia', 'Unit pertama'),
(1, 'EPSON-002', 'Baik', 'Tersedia', 'Unit kedua'),
(1, 'EPSON-003', 'Baik', 'Tersedia', 'Unit ketiga'),
(1, 'EPSON-004', 'Baik', 'Tersedia', 'Unit keempat'),
(1, 'EPSON-005', 'Baik', 'Tersedia', 'Unit kelima'),
-- Sony VPL-EX455 (3 units)
(2, 'SONY-001', 'Baik', 'Tersedia', 'HD Projector'),
(2, 'SONY-002', 'Baik', 'Tersedia', 'HD Projector'),
(2, 'SONY-003', 'Baik', 'Tersedia', 'HD Projector'),
-- Panasonic PT-LB423 (4 units)
(3, 'PANA-001', 'Baik', 'Tersedia', 'Portable unit'),
(3, 'PANA-002', 'Baik', 'Tersedia', 'Portable unit'),
(3, 'PANA-003', 'Baik', 'Tersedia', 'Portable unit'),
(3, 'PANA-004', 'Rusak Ringan', 'Maintenance', 'Lampu redup - dalam perbaikan'),
-- Epson EB-2250U (2 units)
(4, 'EPSON-2250-001', 'Baik', 'Tersedia', 'WUXGA unit'),
(4, 'EPSON-2250-002', 'Baik', 'Tersedia', 'WUXGA unit'),
-- Sony VPL-FHZ75 (1 unit)
(5, 'SONY-FHZ-001', 'Baik', 'Tersedia', 'Laser projector');
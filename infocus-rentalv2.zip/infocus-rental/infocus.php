<?php
// infocus.php - Modern Grouped Version
require_once 'config/database.php';
require_once 'includes/functions.php';

$pageTitle = 'Data Infocus';

$db = new Database();
$conn = $db->connect();

// Handle Add/Edit/Delete
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add') {
            $model = clean($_POST['model']);
            $merk = clean($_POST['merk']);
            $jumlah = intval($_POST['jumlah_unit']);
            $keterangan = clean($_POST['keterangan']);
            
            $foto = '';
            if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
                $upload = uploadFoto($_FILES['foto']);
                if ($upload['success']) {
                    $foto = $upload['filename'];
                } else {
                    setAlert('error', $upload['message']);
                    header('Location: infocus.php');
                    exit();
                }
            }
            
            try {
                $conn->beginTransaction();
                
                // Insert infocus master
                $stmt = $conn->prepare("INSERT INTO infocus (model, merk, jumlah_total, jumlah_tersedia, foto, keterangan) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$model, $merk, $jumlah, $jumlah, $foto, $keterangan]);
                
                $id_infocus = $conn->lastInsertId();
                
                // Insert units
                for ($i = 1; $i <= $jumlah; $i++) {
                    $nomor_seri = strtoupper(substr($merk, 0, 4)) . '-' . str_pad($id_infocus, 3, '0', STR_PAD_LEFT) . '-' . str_pad($i, 3, '0', STR_PAD_LEFT);
                    $stmt = $conn->prepare("INSERT INTO unit_infocus (id_infocus, nomor_seri) VALUES (?, ?)");
                    $stmt->execute([$id_infocus, $nomor_seri]);
                }
                
                $conn->commit();
                setAlert('success', 'Data infocus berhasil ditambahkan dengan ' . $jumlah . ' unit!');
            } catch (Exception $e) {
                $conn->rollBack();
                setAlert('error', 'Gagal menambahkan data: ' . $e->getMessage());
            }
            
        } elseif ($action == 'edit') {
            $id = $_POST['id_infocus'];
            $model = clean($_POST['model']);
            $merk = clean($_POST['merk']);
            $keterangan = clean($_POST['keterangan']);
            
            $foto = '';
            if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
                $upload = uploadFoto($_FILES['foto']);
                if ($upload['success']) {
                    $foto = $upload['filename'];
                    
                    // Hapus foto lama
                    $stmt = $conn->prepare("SELECT foto FROM infocus WHERE id_infocus = ?");
                    $stmt->execute([$id]);
                    $old = $stmt->fetch();
                    if ($old['foto']) {
                        deleteFoto($old['foto']);
                    }
                } else {
                    setAlert('error', $upload['message']);
                    header('Location: infocus.php');
                    exit();
                }
            }
            
            if ($foto) {
                $stmt = $conn->prepare("UPDATE infocus SET model=?, merk=?, foto=?, keterangan=? WHERE id_infocus=?");
                $stmt->execute([$model, $merk, $foto, $keterangan, $id]);
            } else {
                $stmt = $conn->prepare("UPDATE infocus SET model=?, merk=?, keterangan=? WHERE id_infocus=?");
                $stmt->execute([$model, $merk, $keterangan, $id]);
            }
            
            setAlert('success', 'Data infocus berhasil diperbarui!');
            
        } elseif ($action == 'delete') {
            $id = $_POST['id_infocus'];
            
            // Cek apakah ada yang sedang dipinjam
            $stmt = $conn->prepare("
                SELECT COUNT(*) as count FROM unit_infocus u
                WHERE u.id_infocus = ? AND u.status = 'Dipinjam'
            ");
            $stmt->execute([$id]);
            $result = $stmt->fetch();
            
            if ($result['count'] > 0) {
                setAlert('error', 'Tidak dapat menghapus! Masih ada unit yang sedang dipinjam.');
            } else {
                // Hapus foto
                $stmt = $conn->prepare("SELECT foto FROM infocus WHERE id_infocus = ?");
                $stmt->execute([$id]);
                $old = $stmt->fetch();
                if ($old['foto']) {
                    deleteFoto($old['foto']);
                }
                
                // Delete akan cascade ke unit_infocus
                $stmt = $conn->prepare("DELETE FROM infocus WHERE id_infocus = ?");
                $stmt->execute([$id]);
                setAlert('success', 'Data infocus berhasil dihapus!');
            }
            
        } elseif ($action == 'add_unit') {
            $id_infocus = $_POST['id_infocus'];
            $jumlah_tambah = intval($_POST['jumlah_tambah']);
            
            try {
                $conn->beginTransaction();
                
                // Get current total
                $stmt = $conn->prepare("SELECT jumlah_total FROM infocus WHERE id_infocus = ?");
                $stmt->execute([$id_infocus]);
                $current = $stmt->fetch();
                $current_total = $current['jumlah_total'];
                
                // Get merk for serial number
                $stmt = $conn->prepare("SELECT merk FROM infocus WHERE id_infocus = ?");
                $stmt->execute([$id_infocus]);
                $merk = $stmt->fetch()['merk'];
                
                // Add units
                for ($i = 1; $i <= $jumlah_tambah; $i++) {
                    $nomor_seri = strtoupper(substr($merk, 0, 4)) . '-' . str_pad($id_infocus, 3, '0', STR_PAD_LEFT) . '-' . str_pad($current_total + $i, 3, '0', STR_PAD_LEFT);
                    $stmt = $conn->prepare("INSERT INTO unit_infocus (id_infocus, nomor_seri) VALUES (?, ?)");
                    $stmt->execute([$id_infocus, $nomor_seri]);
                }
                
                // Update totals
                $stmt = $conn->prepare("UPDATE infocus SET jumlah_total = jumlah_total + ?, jumlah_tersedia = jumlah_tersedia + ? WHERE id_infocus = ?");
                $stmt->execute([$jumlah_tambah, $jumlah_tambah, $id_infocus]);
                
                $conn->commit();
                setAlert('success', $jumlah_tambah . ' unit berhasil ditambahkan!');
            } catch (Exception $e) {
                $conn->rollBack();
                setAlert('error', 'Gagal menambahkan unit: ' . $e->getMessage());
            }
        }
        
        header('Location: infocus.php');
        exit();
    }
}

// Get all infocus grouped by model
$stmt = $conn->query("SELECT * FROM infocus ORDER BY merk, model");
$dataInfocus = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="mb-0">
            <i class="fas fa-video me-2"></i>Data Infocus
        </h2>
        <p class="text-muted mt-2">Manajemen infocus berdasarkan model</p>
    </div>
    <div class="col-md-6 text-end">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalInfocus" onclick="resetForm()">
            <i class="fas fa-plus me-2"></i>Tambah Model Infocus
        </button>
    </div>
</div>

<?php showAlert(); ?>

<div class="row">
    <?php foreach ($dataInfocus as $row): ?>
        <?php
        // Get unit details
        $stmt = $conn->prepare("SELECT * FROM unit_infocus WHERE id_infocus = ?");
        $stmt->execute([$row['id_infocus']]);
        $units = $stmt->fetchAll();
        ?>
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card infocus-card">
                <div class="row g-0">
                    <div class="col-md-5">
                        <?php if ($row['foto']): ?>
                            <img src="uploads/infocus/<?= $row['foto'] ?>" class="img-fluid w-100" style="height: 100%; object-fit: cover; border-radius: 16px 0 0 16px;" alt="<?= $row['model'] ?>">
                        <?php else: ?>
                            <div class="d-flex align-items-center justify-content-center bg-light" style="height: 100%; border-radius: 16px 0 0 16px;">
                                <i class="fas fa-video fa-3x text-muted"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-7">
                        <div class="card-body p-3">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <h5 class="card-title mb-0" style="font-weight: 700; color: var(--dark);">
                                        <?= $row['merk'] ?>
                                    </h5>
                                    <p class="text-muted mb-2" style="font-size: 0.9rem;"><?= $row['model'] ?></p>
                                </div>
                            </div>
                            
                            <div class="availability-badge mb-3">
                                <i class="fas fa-box"></i>
                                <span><?= $row['jumlah_tersedia'] ?> / <?= $row['jumlah_total'] ?></span>
                            </div>
                            
                            <p class="card-text mb-3" style="font-size: 0.85rem; color: var(--gray-600);">
                                <?= substr($row['keterangan'], 0, 60) ?>...
                            </p>
                            
                            <div class="d-flex gap-2 flex-wrap">
                                <button class="btn btn-sm btn-info" onclick="viewUnits(<?= htmlspecialchars(json_encode($units)) ?>, '<?= $row['merk'] ?> <?= $row['model'] ?>')">
                                    <i class="fas fa-list"></i> Unit
                                </button>
                                <button class="btn btn-sm btn-success" onclick="addUnit(<?= $row['id_infocus'] ?>, '<?= $row['merk'] ?> <?= $row['model'] ?>')">
                                    <i class="fas fa-plus"></i> Tambah
                                </button>
                                <button class="btn btn-sm btn-warning" onclick="editInfocus(<?= htmlspecialchars(json_encode($row)) ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id_infocus" value="<?= $row['id_infocus'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger btn-delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Modal Add/Edit Infocus -->
<div class="modal fade" id="modalInfocus" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Tambah Model Infocus</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data" id="formInfocus">
                <div class="modal-body">
                    <input type="hidden" name="action" id="action" value="add">
                    <input type="hidden" name="id_infocus" id="id_infocus">
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Merk</label>
                            <input type="text" class="form-control" name="merk" id="merk" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Model</label>
                            <input type="text" class="form-control" name="model" id="model" required>
                        </div>
                    </div>
                    
                    <div class="mb-3" id="jumlah_field">
                        <label class="form-label">Jumlah Unit</label>
                        <input type="number" class="form-control" name="jumlah_unit" id="jumlah_unit" min="1" value="1">
                        <small class="text-muted">Nomor seri akan dibuat otomatis</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Foto</label>
                        <input type="file" class="form-control" name="foto" id="foto" accept="image/*">
                        <small class="text-muted">Format: JPG, JPEG, PNG, GIF (Max 5MB)</small>
                        <div id="imagePreview" class="mt-3"></div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Keterangan</label>
                        <textarea class="form-control" name="keterangan" id="keterangan" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal View Units -->
<div class="modal fade" id="modalUnits" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalUnitsTitle">Daftar Unit</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="unitsContent">
            </div>
        </div>
    </div>
</div>

<!-- Modal Add Unit -->
<div class="modal fade" id="modalAddUnit" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalAddUnitTitle">Tambah Unit</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add_unit">
                    <input type="hidden" name="id_infocus" id="add_unit_id">
                    
                    <div class="mb-3">
                        <label class="form-label">Jumlah Unit yang Ditambahkan</label>
                        <input type="number" class="form-control" name="jumlah_tambah" min="1" value="1" required>
                        <small class="text-muted">Nomor seri akan dibuat otomatis melanjutkan nomor terakhir</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-plus me-2"></i>Tambah Unit
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('formInfocus').reset();
    document.getElementById('action').value = 'add';
    document.getElementById('modalTitle').innerText = 'Tambah Model Infocus';
    document.getElementById('imagePreview').innerHTML = '';
    document.getElementById('jumlah_field').style.display = 'block';
}

function editInfocus(data) {
    document.getElementById('action').value = 'edit';
    document.getElementById('id_infocus').value = data.id_infocus;
    document.getElementById('merk').value = data.merk;
    document.getElementById('model').value = data.model;
    document.getElementById('keterangan').value = data.keterangan;
    document.getElementById('modalTitle').innerText = 'Edit Model Infocus';
    document.getElementById('jumlah_field').style.display = 'none';
    
    if (data.foto) {
        document.getElementById('imagePreview').innerHTML = '<img src="uploads/infocus/' + data.foto + '" class="image-preview">';
    }
    
    var modal = new bootstrap.Modal(document.getElementById('modalInfocus'));
    modal.show();
}

function viewUnits(units, title) {
    document.getElementById('modalUnitsTitle').innerText = 'Daftar Unit - ' + title;
    
    let html = '<div class="table-responsive"><table class="table table-sm">';
    html += '<thead><tr><th>No</th><th>Nomor Seri</th><th>Kondisi</th><th>Status</th><th>Keterangan</th></tr></thead><tbody>';
    
    units.forEach((unit, index) => {
        let statusClass = unit.status == 'Tersedia' ? 'success' : (unit.status == 'Dipinjam' ? 'warning' : 'danger');
        let kondisiClass = unit.kondisi == 'Baik' ? 'success' : (unit.kondisi == 'Rusak Ringan' ? 'warning' : 'danger');
        
        html += '<tr>';
        html += '<td>' + (index + 1) + '</td>';
        html += '<td><strong>' + unit.nomor_seri + '</strong></td>';
        html += '<td><span class="badge bg-' + kondisiClass + '">' + unit.kondisi + '</span></td>';
        html += '<td><span class="badge bg-' + statusClass + '">' + unit.status + '</span></td>';
        html += '<td>' + (unit.keterangan_unit || '-') + '</td>';
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    
    document.getElementById('unitsContent').innerHTML = html;
    
    var modal = new bootstrap.Modal(document.getElementById('modalUnits'));
    modal.show();
}

function addUnit(id, title) {
    document.getElementById('modalAddUnitTitle').innerText = 'Tambah Unit - ' + title;
    document.getElementById('add_unit_id').value = id;
    
    var modal = new bootstrap.Modal(document.getElementById('modalAddUnit'));
    modal.show();
}
</script>

<?php include 'includes/footer.php'; ?>
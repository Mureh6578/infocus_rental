@echo off
title Setup Infocus Rental (FIX)

set BASE=%cd%
set PROJECT=infocus-rental

echo Membuat folder project...

:: Folder utama
if not exist "%PROJECT%" mkdir "%PROJECT%"
cd "%PROJECT%"

:: ===============================
:: BUAT FOLDER
:: ===============================
mkdir assets
mkdir assets\css
mkdir assets\js
mkdir config
mkdir includes
mkdir uploads
mkdir uploads\infocus

:: ===============================
:: BUAT FILE (PAKAI TYPE NUL)
:: ===============================
type nul > assets\css\style.css
type nul > assets\js\script.js

type nul > config\database.php

type nul > includes\functions.php
type nul > includes\header.php
type nul > includes\footer.php

type nul > login.php
type nul > logout.php
type nul > index.php
type nul > infocus.php
type nul > peminjam.php
type nul > peminjaman.php
type nul > riwayat.php
type nul > get_detail.php

type nul > README.md

echo.
echo ===============================
echo SELESAI
echo ===============================
echo Folder DAN file berhasil dibuat
echo Lokasi: %BASE%\%PROJECT%
echo.

pause

// assets/js/script.js

$(document).ready(function() {
    // Auto dismiss alerts
    setTimeout(function() {
        $('.alert').fadeOut('slow');
    }, 5000);
    
    // Confirm delete
    $('.btn-delete').click(function(e) {
        if (!confirm('Apakah Anda yakin ingin menghapus data ini?')) {
            e.preventDefault();
        }
    });
    
    // Image preview
    $('#foto').change(function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreview').html('<img src="' + e.target.result + '" class="image-preview">');
            }
            reader.readAsDataURL(file);
        }
    });
    
    // Format number input
    $('.number-only').keypress(function(e) {
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            return false;
        }
    });
    
    // Add animation to cards
    $('.card').addClass('fade-in');
    
    // DataTable initialization (if you want to add later)
    if (typeof $.fn.DataTable !== 'undefined') {
        $('.data-table').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Indonesian.json"
            }
        });
    }
});

// Function to calculate date difference
function hitungSelisihHari(tanggalMulai, tanggalAkhir) {
    const oneDay = 24 * 60 * 60 * 1000;
    const firstDate = new Date(tanggalMulai);
    const secondDate = new Date(tanggalAkhir);
    
    return Math.round(Math.abs((firstDate - secondDate) / oneDay));
}

// Function to validate date
function validateDate() {
    const tanggalPinjam = document.getElementById('tanggal_pinjam');
    const tanggalKembali = document.getElementById('tanggal_kembali_rencana');
    
    if (tanggalPinjam && tanggalKembali) {
        const pinjam = new Date(tanggalPinjam.value);
        const kembali = new Date(tanggalKembali.value);
        
        if (kembali < pinjam) {
            alert('Tanggal kembali tidak boleh lebih awal dari tanggal pinjam!');
            tanggalKembali.value = '';
            return false;
        }
    }
    return true;
}

// Function to show loading
function showLoading() {
    const loading = '<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
    return loading;
}

// Function to format currency
function formatRupiah(angka) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(angka);
}

// Function to format date to Indonesian
function formatTanggalIndonesia(tanggal) {
    const bulan = [
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    
    const d = new Date(tanggal);
    return d.getDate() + ' ' + bulan[d.getMonth()] + ' ' + d.getFullYear();
}
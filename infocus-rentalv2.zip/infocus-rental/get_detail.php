<?php
// riwayat.php - Modern Version
require_once 'config/database.php';
require_once 'includes/functions.php';

$pageTitle = 'Riwayat Peminjaman';

$db = new Database();
$conn = $db->connect();

// Get all peminjaman with details
$stmt = $conn->query("
    SELECT p.*, pm.nama as nama_peminjam, pm.nip, a.nama_lengkap as nama_admin
    FROM peminjaman p
    JOIN peminjam pm ON p.id_peminjam = pm.id_peminjam
    JOIN admin a ON p.id_admin = a.id_admin
    ORDER BY p.created_at DESC
");
$dataRiwayat = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="row mb-4">
    <div class="col-12">
        <h2 class="mb-0">
            <i class="fas fa-history me-2"></i>Riwayat Peminjaman
        </h2>
        <p class="text-muted mt-2">Semua histori transaksi peminjaman</p>
    </div>
</div>

<?php showAlert(); ?>

<div class="card">
    <div class="card-body">
        <?php if (count($dataRiwayat) > 0): ?>
        <div class="table-responsive">
            <table class="table table-custom table-hover mb-0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID</th>
                        <th>Tanggal Pinjam</th>
                        <th>Peminjam</th>
                        <th>Jumlah Unit</th>
                        <th>Tanggal Kembali</th>
                        <th>Tgl Kembali Aktual</th>
                        <th>Status</th>
                        <th>Keperluan</th>
                        <th>Admin</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($dataRiwayat as $index => $row): ?>
                    <?php
                    // Get detail infocus
                    $stmt = $conn->prepare("
                        SELECT i.merk, i.model, u.nomor_seri, dp.kondisi_pinjam, dp.kondisi_kembali
                        FROM detail_peminjaman dp
                        JOIN unit_infocus u ON dp.id_unit = u.id_unit
                        JOIN infocus i ON u.id_infocus = i.id_infocus
                        WHERE dp.id_peminjaman = ?
                    ");
                    $stmt->execute([$row['id_peminjaman']]);
                    $infocusDetail = $stmt->fetchAll();
                    
                    // Calculate late days
                    $lateDays = 0;
                    if ($row['tanggal_kembali_aktual']) {
                        $kembali_rencana = new DateTime($row['tanggal_kembali_rencana']);
                        $kembali_aktual = new DateTime($row['tanggal_kembali_aktual']);
                        if ($kembali_aktual > $kembali_rencana) {
                            $lateDays = $kembali_rencana->diff($kembali_aktual)->days;
                        }
                    }
                    ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><strong>#<?= str_pad($row['id_peminjaman'], 4, '0', STR_PAD_LEFT) ?></strong></td>
                        <td><?= formatTanggal($row['tanggal_pinjam']) ?></td>
                        <td>
                            <strong><?= $row['nama_peminjam'] ?></strong><br>
                            <small class="text-muted"><?= $row['nip'] ?></small>
                        </td>
                        <td>
                            <span class="badge bg-info"><?= count($infocusDetail) ?> Unit</span>
                        </td>
                        <td><?= formatTanggal($row['tanggal_kembali_rencana']) ?></td>
                        <td>
                            <?php if ($row['tanggal_kembali_aktual']): ?>
                                <?= formatTanggal($row['tanggal_kembali_aktual']) ?>
                                <?php if ($lateDays > 0): ?>
                                    <br><span class="badge bg-warning text-dark">Terlambat <?= $lateDays ?> hari</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $statusClass = 'status-' . strtolower($row['status']);
                            ?>
                            <span class="badge <?= $statusClass ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td><?= substr($row['keperluan'], 0, 30) ?>...</td>
                        <td><?= $row['nama_admin'] ?></td>
                        <td>
                            <button class="btn btn-sm btn-info" onclick="viewFullDetail(<?= $row['id_peminjaman'] ?>)">
                                <i class="fas fa-eye"></i> Detail
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
            <p class="text-muted">Belum ada riwayat peminjaman</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Full Detail -->
<div class="modal fade" id="modalFullDetail" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Peminjaman</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="fullDetailContent">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function viewFullDetail(id) {
    // Load full detail via AJAX
    fetch('get_detail.php?id=' + id)
        .then(response => response.text())
        .then(data => {
            document.getElementById('fullDetailContent').innerHTML = data;
        })
        .catch(error => {
            document.getElementById('fullDetailContent').innerHTML = '<div class="alert alert-danger">Gagal memuat data</div>';
        });
    
    var modal = new bootstrap.Modal(document.getElementById('modalFullDetail'));
    modal.show();
}
</script>

<?php include 'includes/footer.php'; ?>